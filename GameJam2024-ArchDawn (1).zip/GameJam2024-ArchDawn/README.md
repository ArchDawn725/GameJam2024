Updated Cretaceous Catastrophe/Defcon Dino/Ground Asteroid
